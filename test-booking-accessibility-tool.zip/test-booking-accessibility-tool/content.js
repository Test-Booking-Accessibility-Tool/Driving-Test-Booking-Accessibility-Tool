console.log("Test Booking Accessibility Tool content script loaded");

let watcherTimer = null;
let alarmInterval = null;
let pageMonitorInterval = null;
let alarmActive = false;

function parseDateUK(dateText) {
  const [day, month, year] = dateText.split("/").map(Number);
  return new Date(year, month - 1, day);
}

function playBeep() {
  try {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();

    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
    gainNode.gain.setValueAtTime(0.45, audioContext.currentTime);

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.start();

    setTimeout(() => {
      oscillator.stop();
      audioContext.close();
    }, 500);
  } catch (error) {
    console.log("Alarm sound failed:", error);
  }
}

function isResultsPage() {
  const pageText = document.body ? document.body.innerText : "";

  return (
    pageText.includes("Your search results") &&
    pageText.includes("Please choose one of the test centres below")
  );
}

function startAlarm(message) {
  if (alarmActive) return;

  alarmActive = true;

  stopAlarm(false);

  alarmActive = true;

  // Start sound before alert appears.
  playBeep();

  alarmInterval = setInterval(() => {
    playBeep();
  }, 1500);

  // Show alert slightly after the sound starts.
  setTimeout(() => {
    alert(message);
  }, 300);

  // Keep alarming while user stays on the results page.
  // Stop once they manually move to another screen.
  pageMonitorInterval = setInterval(() => {
    if (!isResultsPage()) {
      stopAlarm(true);
    }
  }, 1000);
}

function stopAlarm(resetActive = true) {
  if (alarmInterval) {
    clearInterval(alarmInterval);
    alarmInterval = null;
  }

  if (pageMonitorInterval) {
    clearInterval(pageMonitorInterval);
    pageMonitorInterval = null;
  }

  if (resetActive) {
    alarmActive = false;
  }
}

function getRandomisedInterval(baseInterval) {
  const variation = Math.floor(baseInterval * 0.15);
  const offset = Math.floor(Math.random() * (variation * 2 + 1)) - variation;
  return baseInterval + offset;
}

function detectSecurityWall() {
  const text = document.body ? document.body.innerText : "";

  return (
    text.includes("Additional security check is required") ||
    text.includes("Why am I seeing this page?") ||
    text.includes("I am human") ||
    text.includes("Imperva")
  );
}

function getFirstResultAfterHeading() {
  const pageText = document.body ? document.body.innerText : "";

  if (detectSecurityWall()) {
    return {
      success: false,
      centreName: "Security Check",
      firstDate: "None",
      resultText: "⚠️ SECURITY CHECK REQUIRED",
      found: false,
      securityWall: true
    };
  }

  const heading = "Please choose one of the test centres below";
  const headingIndex = pageText.indexOf(heading);

  if (headingIndex === -1) {
    return {
      success: false,
      centreName: "Unknown",
      firstDate: "None",
      resultText: "Results heading not found",
      found: false,
      securityWall: false
    };
  }

  const textAfterHeading = pageText.slice(headingIndex + heading.length);

  const lines = textAfterHeading
    .split("\n")
    .map(line => line.trim())
    .filter(line => line.length > 0);

  const firstResultLine = lines[0] || "";

  const availableMatch = firstResultLine.match(
    /^(.+?)\s+–\s+available tests around\s+(\d{2}\/\d{2}\/\d{4})$/i
  );

  const noTestsMatch = firstResultLine.match(
    /^(.+?)\s+–\s+No tests found on any date$/i
  );

  if (availableMatch) {
    return {
      success: true,
      centreName: availableMatch[1].trim(),
      firstDate: availableMatch[2],
      resultText: "Availability found",
      found: false,
      securityWall: false
    };
  }

  if (noTestsMatch) {
    return {
      success: true,
      centreName: noTestsMatch[1].trim(),
      firstDate: "None",
      resultText: "No tests found on any date",
      found: false,
      securityWall: false
    };
  }

  return {
    success: false,
    centreName: "Unknown",
    firstDate: "None",
    resultText: `Could not read first result: ${firstResultLine}`,
    found: false,
    securityWall: false
  };
}

function findTestCentresButton() {
  const elements = Array.from(
    document.querySelectorAll("button, input[type='submit'], a")
  );

  return elements.find(element => {
    const text = (
      element.innerText ||
      element.value ||
      element.getAttribute("aria-label") ||
      ""
    ).trim().toLowerCase();

    return text.includes("find test centres");
  });
}

function checkAndStoreResult(options = {}, callback) {
  const allowAlarm = options.allowAlarm === true;
  const result = getFirstResultAfterHeading();

  chrome.storage.local.get(
    ["fromDate", "toDate", "watching", "alarmAlreadyTriggered"],
    (data) => {
      let found = false;
      let resultText = result.resultText;

      if (result.securityWall) {
        chrome.storage.local.set({
          watching: false,
          pageRead: true,
          centreName: result.centreName,
          firstDate: result.firstDate,
          resultText: "⚠️ SECURITY CHECK REQUIRED",
          found: false,
          securityWall: true,
          lastCheck: new Date().toLocaleTimeString()
        });

        stopWatching();

        if (allowAlarm && !data.alarmAlreadyTriggered) {
          chrome.storage.local.set({
            alarmAlreadyTriggered: true
          });

          startAlarm(
            "DVSA security check detected.\n\nMonitoring has stopped. Please complete the security check manually."
          );
        }

        if (callback) callback(result);
        return;
      }

      if (
        result.success &&
        result.firstDate !== "None" &&
        data.fromDate &&
        data.toDate
      ) {
        const testDate = parseDateUK(result.firstDate);
        const fromDate = new Date(data.fromDate + "T00:00:00");
        const toDate = new Date(data.toDate + "T23:59:59");

        found =
          testDate.getTime() >= fromDate.getTime() &&
          testDate.getTime() <= toDate.getTime();

        resultText = found
          ? "🚨 MATCH FOUND"
          : "Date outside selected range";
      }

      chrome.storage.local.set({
        pageRead: true,
        centreName: result.centreName,
        firstDate: result.firstDate,
        resultText,
        found,
        securityWall: false,
        lastCheck: new Date().toLocaleTimeString()
      });

      if (found && allowAlarm && !data.alarmAlreadyTriggered) {
        chrome.storage.local.set({
          watching: false,
          alarmAlreadyTriggered: true
        });

        stopWatching();

        startAlarm(
          `Driving test found!\n\n${result.centreName}\n${result.firstDate}\n\nPlease continue manually on GOV.UK.`
        );
      }

      if (callback) callback(result);
    }
  );
}

function clickFindTestCentres() {
  const button = findTestCentresButton();

  if (!button) {
    chrome.storage.local.set({
      resultText: "Find test centres button not found",
      lastCheck: new Date().toLocaleTimeString()
    });
    return;
  }

  button.click();
}

function scheduleNextCheck() {
  chrome.storage.local.get(
    ["watching", "interval", "refreshCount"],
    (data) => {
      if (!data.watching) return;

      const baseInterval = Number(data.interval) || 60000;
      const nextInterval = getRandomisedInterval(baseInterval);

      chrome.storage.local.set({
        nextIntervalMs: nextInterval
      });

      watcherTimer = setTimeout(() => {
        chrome.storage.local.get(
          ["watching", "refreshCount"],
          (latest) => {
            if (!latest.watching) {
              stopWatching();
              return;
            }

            const count = (latest.refreshCount || 0) + 1;

            chrome.storage.local.set({
              refreshCount: count
            });

            checkAndStoreResult({ allowAlarm: true }, (result) => {
              if (result.securityWall) return;
              if (result.found) return;

              setTimeout(() => {
                clickFindTestCentres();
                scheduleNextCheck();
              }, 1000);
            });
          }
        );
      }, nextInterval);
    }
  );
}

function startWatching() {
  stopAlarm();
  stopWatching();

  chrome.storage.local.set({
    alarmAlreadyTriggered: false
  });

  // Immediate fail-safe:
  // If a matching date is already visible when watching starts,
  // alarm immediately.
  checkAndStoreResult({ allowAlarm: true }, (result) => {
    if (result.securityWall) return;
    if (result.found) return;

    scheduleNextCheck();
  });
}

function stopWatching() {
  if (watcherTimer) {
    clearTimeout(watcherTimer);
    watcherTimer = null;
  }

  stopAlarm();
}

chrome.storage.onChanged.addListener((changes) => {
  if (changes.watching) {
    if (changes.watching.newValue) {
      startWatching();
    } else {
      stopWatching();
    }
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "checkPage") {
    checkAndStoreResult({ allowAlarm: true }, () => {
      setTimeout(() => {
        clickFindTestCentres();
      }, 500);
    });

    sendResponse({ ok: true });
    return true;
  }

  if (message.action === "stopAlarm") {
    stopAlarm();
    sendResponse({ ok: true });
    return true;
  }
});

// Initial read only.
// This updates the popup, but does NOT alarm until the user presses Start Watching or Check Page Now.
checkAndStoreResult({ allowAlarm: false });

chrome.storage.local.get(["watching"], (data) => {
  if (data.watching) {
    startWatching();
  }
});
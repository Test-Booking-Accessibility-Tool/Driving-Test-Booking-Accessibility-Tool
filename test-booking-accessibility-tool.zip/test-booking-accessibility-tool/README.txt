# Test Booking Accessibility Tool

Chrome / Chromium development build.

## Install for testing
1. Unzip this folder.
2. Open Chrome and go to `chrome://extensions`.
3. Turn on Developer mode.
4. Click Load unpacked.
5. Select the `test-booking-accessibility-tool` folder.

This is a local development build and is not packaged as a Chrome Web Store extension.

const fromDateInput = document.getElementById("fromDate");
const toDateInput = document.getElementById("toDate");
const intervalInput = document.getElementById("interval");

const statusText = document.getElementById("status");
const countdownText = document.getElementById("countdown");

const centreNameText = document.getElementById("centreName");
const firstDateText = document.getElementById("firstDate");
const lastCheckText = document.getElementById("lastCheck");
const pageReadText = document.getElementById("pageRead");
const resultText = document.getElementById("result");
const refreshCountText = document.getElementById("refreshCount");

let countdownTimer = null;
let alarmTimer = null;
let audioContext = null;
let alarmRunning = false;

function unlockAudio() {
  if (!audioContext) {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
  }

  if (audioContext.state === "suspended") {
    audioContext.resume();
  }
}

function playBeep() {
  unlockAudio();

  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();

  oscillator.type = "sine";
  oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
  gainNode.gain.setValueAtTime(0.45, audioContext.currentTime);

  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);

  oscillator.start();

  setTimeout(() => {
    oscillator.stop();
  }, 500);
}

function startAlarm() {
  if (alarmRunning) return;

  alarmRunning = true;
  playBeep();

  alarmTimer = setInterval(() => {
    playBeep();
  }, 1500);
}

function stopAlarm() {
  alarmRunning = false;

  if (alarmTimer) {
    clearInterval(alarmTimer);
    alarmTimer = null;
  }
}

function startCountdown(interval) {
  clearInterval(countdownTimer);

  let remaining = Math.floor(interval / 1000);

  countdownTimer = setInterval(() => {
    const minutes = Math.floor(remaining / 60);
    const seconds = remaining % 60;

    countdownText.textContent =
      `Next refresh in: ${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;

    remaining--;

    if (remaining < 0) {
      remaining = Math.floor(interval / 1000);
    }
  }, 1000);
}

function stopCountdown() {
  clearInterval(countdownTimer);
  countdownText.textContent = "Next refresh: --:--";
}

function loadLatestStatus() {
  chrome.storage.local.get(
    [
      "lastCheck",
      "pageRead",
      "centreName",
      "firstDate",
      "resultText",
      "refreshCount",
      "watching",
      "found",
      "securityWall"
    ],
    (data) => {
      lastCheckText.textContent = data.lastCheck || "Never";
      pageReadText.textContent = data.pageRead ? "Yes" : "No";
      centreNameText.textContent = data.centreName || "Unknown";
      firstDateText.textContent = data.firstDate || "None";
      resultText.textContent = data.resultText || "No check yet";
      refreshCountText.textContent = data.refreshCount || 0;

      if (data.found || data.securityWall) {
        startAlarm();
      }

      if (!data.watching) {
        statusText.textContent = "Not watching";
      }
    }
  );
}

async function saveSettings() {
  await chrome.storage.local.set({
    fromDate: fromDateInput.value,
    toDate: toDateInput.value,
    interval: Number(intervalInput.value)
  });
}

async function resetMatchState() {
  stopAlarm();

  await chrome.storage.local.set({
    found: false,
    alarmAlreadyTriggered: false,
    securityWall: false,
    resultText: "Rechecking...",
    watching: false
  });

  stopCountdown();
  statusText.textContent = "Not watching";
}

async function checkPageNow() {
  unlockAudio();
  await saveSettings();

  await chrome.storage.local.set({
    found: false,
    alarmAlreadyTriggered: false,
    securityWall: false,
    resultText: "Checking page..."
  });

  chrome.runtime.sendMessage({ action: "checkPage" });

  setTimeout(loadLatestStatus, 1000);
}

document.getElementById("startBtn").addEventListener("click", async () => {
  unlockAudio();

  const fromDate = fromDateInput.value;
  const toDate = toDateInput.value;
  const interval = Number(intervalInput.value);

  if (!fromDate || !toDate) {
    statusText.textContent = "Please choose both dates.";
    return;
  }

  stopAlarm();

  await chrome.storage.local.set({
    watching: true,
    fromDate,
    toDate,
    interval,
    found: false,
    alarmAlreadyTriggered: false,
    securityWall: false,
    refreshCount: 0,
    resultText: "Watching..."
  });

  chrome.runtime.sendMessage({ action: "startWatching" });

  statusText.textContent = "Watching for test dates...";
  startCountdown(interval);

  setTimeout(loadLatestStatus, 1000);
});

document.getElementById("stopBtn").addEventListener("click", async () => {
  stopAlarm();

  await chrome.storage.local.set({
    watching: false,
    found: false,
    alarmAlreadyTriggered: false,
    securityWall: false,
    resultText: "Stopped"
  });

  chrome.runtime.sendMessage({ action: "stopWatching" });

  statusText.textContent = "Stopped.";
  stopCountdown();

  setTimeout(loadLatestStatus, 500);
});

document.getElementById("checkNowBtn").addEventListener("click", checkPageNow);

fromDateInput.addEventListener("change", async () => {
  await saveSettings();
  await resetMatchState();
  await checkPageNow();
});

toDateInput.addEventListener("change", async () => {
  await saveSettings();
  await resetMatchState();
  await checkPageNow();
});

intervalInput.addEventListener("change", async () => {
  await saveSettings();
});

chrome.storage.local.get(["watching", "fromDate", "toDate", "interval"], (data) => {
  if (data.fromDate) fromDateInput.value = data.fromDate;
  if (data.toDate) toDateInput.value = data.toDate;
  if (data.interval) intervalInput.value = data.interval;

  if (data.watching) {
    statusText.textContent = "Watching...";
    startCountdown(data.interval || 60000);
  } else {
    statusText.textContent = "Not watching";
    stopCountdown();
  }

  loadLatestStatus();
});

setInterval(loadLatestStatus, 1000);
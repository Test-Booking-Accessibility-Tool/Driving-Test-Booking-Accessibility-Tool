chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "startWatching") {
    chrome.storage.local.set({
      watching: true,
      refreshCount: 0
    });
  }

  if (message.action === "stopWatching") {
    chrome.storage.local.set({
      watching: false
    });
  }

  if (message.action === "checkPage") {
    chrome.storage.local.set({
      manualCheckRequested: Date.now()
    });
  }
});